package com.cg.rms.service;

import java.util.List;

import com.cg.rms.dto.JobRequirements;
import com.cg.rms.dto.Admin;
import com.cg.rms.dto.CandidateBeanPersonal;
import com.cg.rms.dto.CandidateBeanQualification;
import com.cg.rms.dto.CandidateBeanWorkHistory;
import com.cg.rms.dto.CompanyMaster;
import com.cg.rms.exception.RecruitmentException;

public interface CourseService {
	
	String insertCourse(CandidateBeanPersonal cource) throws RecruitmentException;
	String insertCandidateBeanQualification(CandidateBeanQualification cqualifications) throws RecruitmentException;
	String insertCandidateBeanWorkHistory(CandidateBeanWorkHistory chistory) throws RecruitmentException;
	
	boolean updateCourse(CandidateBeanPersonal cource) throws RecruitmentException;
	boolean updateCandidateBeanQualification(CandidateBeanQualification cqualifications) throws RecruitmentException;
	boolean updatCandidateBeanWorkHistory(CandidateBeanWorkHistory chistory) throws RecruitmentException;
	public int login(String username, String password, String role) throws RecruitmentException;
	String addCompanyDetails(CompanyMaster cmaster) throws RecruitmentException;
	boolean updateCompanyDetails() throws RecruitmentException;
	List<CandidateBeanQualification> searchjobs(String string) throws RecruitmentException;
	List<CandidateBeanWorkHistory> searchjobs2(String jreq)	throws RecruitmentException;
	List<JobRequirements> searchjobs3(JobRequirements jreq) throws RecruitmentException;
	public int insertJobReq(JobRequirements jreq) throws RecruitmentException;
	int apply(String candidate_id,String job_id,String company_id) throws RecruitmentException;
	public List<Admin> getAllCandidate() throws RecruitmentException;
	boolean validateCourse(CandidateBeanPersonal cource) throws RecruitmentException;
	boolean validateCandiQualif(CandidateBeanQualification cqualifications) throws RecruitmentException;
}
