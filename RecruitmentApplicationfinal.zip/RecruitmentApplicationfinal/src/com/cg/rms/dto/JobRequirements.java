package com.cg.rms.dto;
//Bean for job Requirements
public class JobRequirements {
	String job_id;
	String company_id;
	String position_required;
	Long number_required;
	Long experience_required;
	String qualification_required;
	String job_location;
	String job_description;
	public String getJob_id() {
		return job_id;
	}
	public void setJob_id(String job_id) {
		this.job_id = job_id;
	}
	public String getCompany_id() {
		return company_id;
	}
	public void setCompany_id(String company_id) {
		this.company_id = company_id;
	}
	public String getPosition_required() {
		return position_required;
	}
	public void setPosition_required(String position_required) {
		this.position_required = position_required;
	}
	public Long getNumbers_required() {
		return number_required;
	}
	public void setNumbers_required(Long numbers_required) {
		this.number_required = numbers_required;
	}
	public Long getExperience_required() {
		return experience_required;
	}
	public void setExperience_required(Long experience_required) {
		this.experience_required = experience_required;
	}
	public String getQualification_required() {
		return qualification_required;
	}
	public void setQualification_required(String qualification_required) {
		this.qualification_required = qualification_required;
	}
	public String getJob_location() {
		return job_location;
	}
	public void setJob_location(String job_location) {
		this.job_location = job_location;
	}
	public String getJob_description() {
		return job_description;
	}
	public void setJob_description(String job_description) {
		this.job_description = job_description;
	}
	@Override
	public String toString() {
		return "JobRequirements [job_id=" + job_id + ", company_id=" + company_id + ", position_required="
				+ position_required + ", numbers_required=" + number_required + ", experience_required="
				+ experience_required + ", qualification_required=" + qualification_required + ", job_location="
				+ job_location + ", job_description=" + job_description + "]";
	}
	public JobRequirements() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
