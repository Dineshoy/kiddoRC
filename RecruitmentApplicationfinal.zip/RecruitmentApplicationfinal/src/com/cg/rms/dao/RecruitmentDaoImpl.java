package com.cg.rms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.rms.dto.Admin;
import com.cg.rms.dto.CandidateBeanPersonal;
import com.cg.rms.dto.CandidateBeanQualification;
import com.cg.rms.dto.CandidateBeanWorkHistory;
import com.cg.rms.dto.CompanyMaster;
import com.cg.rms.dto.JobRequirements;
import com.cg.rms.exception.RecruitmentException;


public class RecruitmentDaoImpl implements RecruitmentDao {

	Logger logger=null;
	Connection conn=null;
	Statement st=null;
	PreparedStatement pst=null;
	PreparedStatement pst2=null;
	ResultSet rs=null;
	int data=0;
	int data2=0;
	public RecruitmentDaoImpl() {
		// TODO Auto-generated constructor stub
		logger=Logger.getLogger(RecruitmentDaoImpl.class);
		PropertyConfigurator.configure("log4j.properties");
	}
	
	
	
	//sequence for generating candidate_id
	private String generateCourseId() throws RecruitmentException{
		
		conn = DBUtil.getConnection();
		String sql = "SELECT seq_course_id.NEXTVAL FROM DUAL";
		try {
			Statement st = conn.createStatement();
			ResultSet rst = st.executeQuery(sql);
			rst.next();
			return rst.getString(1);
		} catch (SQLException e) {
			
			throw new RecruitmentException("problem in generating course Id"+e.getMessage());
			//e.printStackTrace();
		}
	}
	
	
	//sequence for generating qualification_id
private String generateQualificationId() throws RecruitmentException{
		
		conn = DBUtil.getConnection();
		String sql = "SELECT seq_qualification_id.NEXTVAL FROM DUAL";
		try {
			Statement st = conn.createStatement();
			ResultSet rst = st.executeQuery(sql);
			rst.next();
			return rst.getString(1);
		} catch (SQLException e) {
			
			throw new RecruitmentException("problem in generating qualifications Id"+e.getMessage());
			//e.printStackTrace();
		}
	}

//sequence for generating job_id
private String generateWorkId() throws RecruitmentException{
	
	conn = DBUtil.getConnection();
	String sql = "SELECT seq_work_id.NEXTVAL FROM DUAL";
	try {
		Statement st = conn.createStatement();
		ResultSet rst = st.executeQuery(sql);
		rst.next();
		return rst.getString(1);
	} catch (SQLException e) {
		throw new RecruitmentException("problem in generating work Id"+e.getMessage());
	}
}


//sequence for generating company_id
private String generateRegistrationId() throws RecruitmentException{
	String sql = "SELECT seq_company_id.NEXTVAl FROM DUAL";
	conn = DBUtil.getConnection();
	try {
	Statement st = conn.createStatement();
	ResultSet rst = st.executeQuery(sql);
	rst.next();
	return rst.getString(1);
}catch (SQLException e) {
	throw new RecruitmentException("problem in company id"+e.getMessage());
}
}


//method for inserting personal details of candidate.
	@Override
	public String insertCourse(CandidateBeanPersonal cource) throws RecruitmentException {
	String sql = "INSERT INTO cource values(?,?,?,?,?,?,?,?,?)";
	cource.setCandidate_id(generateCourseId());
	conn = DBUtil.getConnection();
	PreparedStatement pst;
	try {
		pst = conn.prepareStatement(sql);
		pst.setString(1, cource.getCandidate_id());
		pst.setString(2, cource.getCandidate_name());
		pst.setString(3, cource.getAddress());
		pst.setString(4, cource.getDOB());
		pst.setString(5, cource.getEmail_id());
		pst.setString(6, cource.getContact_number());
		pst.setString(7, cource.getMaritial_status());
		pst.setString(8, cource.getGender());
		pst.setString(9, cource.getPassport_number());
		
		
		pst.executeUpdate();
	} catch (SQLException e) {
		logger.error("Problem in inserting the details");
		throw new RecruitmentException("problem in insering the deatails"+e.getMessage());
		//e.printStackTrace();
	}
	logger.info("Data inserted successfully in recruitments systems");
	 return cource.getCandidate_id();
	}
	
	//method for inserting Qualification details of candidate.
	@Override
	public String insertCandidateQualifications(CandidateBeanQualification cqualifications) throws RecruitmentException {
		
		String sql = "INSERT INTO Candidate_Qualifications values(?,?,?,?,?,?,?,?)";
		cqualifications.setQualification_id(generateQualificationId());
		conn = DBUtil.getConnection();
		PreparedStatement pst;
		try {
			pst = conn.prepareStatement(sql);
			pst.setString(1, cqualifications.getQualification_id());
			pst.setString(2, cqualifications.getQualification_name());
			pst.setString(3, cqualifications.getSpecialization_area());
			pst.setString(4,cqualifications.getCollege_name());
			pst.setString(5,cqualifications.getUniversity_name());
			pst.setString(6,cqualifications.getYear_of_passing());
			pst.setString(7,cqualifications.getPercentage());
			pst.setString(8,cqualifications.getCandidate_id());
			pst.executeUpdate();
			} catch (SQLException e) {
				logger.error("Problem in inserting the details");
			throw new  RecruitmentException("problem in insering the details"+e.getMessage());
			//e.printStackTrace();
		}logger.info("Data inserted successfully in recruitments systems");
		return cqualifications.getQualification_id();
	}
	
	//method for inserting work History details of candidate.
		@Override
		public String insertCandidateWorkHistory(CandidateBeanWorkHistory chistory) throws RecruitmentException {
			
			
			chistory.setWork_id(generateWorkId());
			String sql ="INSERT INTO candidate_work_history VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
			conn = DBUtil.getConnection();
			try {
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1, chistory.getWork_id());
			pst.setString(2, chistory.getCandidate_id());
			pst.setString(3, chistory.getWhich_employer());
			pst.setString(4, chistory.getContact_person());
			pst.setString(5, chistory.getPosition_held());
			pst.setString(6, chistory.getCompany_name());
			pst.setString(7, chistory.getEmployement_from());
			pst.setString(8, chistory.getEmployement_to());
			pst.setString(9, chistory.getReason_for_leaving());
			pst.setString(10, chistory.getResponsibilities());
			pst.setString(11, chistory.getHr_rep_name());
			pst.setString(12, chistory.getHr_rep_contact_num());
			
			pst.executeUpdate();
			//logger.info("Registration completed successfully for"+cmaster);
			
		}catch (SQLException e) {
			logger.error("Problem in inserting the details");
			throw new RecruitmentException("problem in inserting"
					+"work history details"+e.getMessage());
		}
			logger.info("Data inserted successfully in recruitments systems");
			return chistory.getWork_id();
	}
	
	
	//method for updating personal details
	@Override
	public boolean updateCourse(CandidateBeanPersonal cource) throws RecruitmentException {
		
		
		Scanner sc = new Scanner(System.in);
		System.out.println("enter candidate ID");
	String	id = sc.next();
	
	
	    String sql = "UPDATE cource SET candidate_name =?, address=?, DOB =?, email_id=?, contact_number=?, Marital_status=?, gender=?, Passport_number=? where candidate_id=?"; 
		conn = DBUtil.getConnection();
		PreparedStatement pst;
		
		System.out.println("Enter the Details");
		System.out.println("Enter New Name of Candidate");
		String nm = sc.next();
		System.out.println("enter Address");
		String add = sc.next();
		System.out.println("enter DOB");
		String dob=sc.next();
		System.out.println("enter Email ID");
		String email=sc.next();
		System.out.println("enter contact no");
		String cno=sc.next();
		System.out.println("enter Maritial Status");
		String mstatus=sc.next();
		System.out.println("Enter your gender");
		String gender=sc.next();
		System.out.println("enter passport number");
		String pno=sc.next();
		
		try {
			pst = conn.prepareStatement(sql);
			
			pst.setString(1, nm);
			pst.setString(2, add);
			pst.setString(3, dob);
			pst.setString(4, email);
			pst.setString(5, cno);
			pst.setString(6, mstatus);
			pst.setString(7, gender);
			pst.setString(8, pno);
			pst.setString(9, id);
			pst.executeUpdate();
		} catch (SQLException e) {
			logger.error("Problem in inserting the details");
			throw new RecruitmentException("problem in updating the details"+e.getMessage());
			//e.printStackTrace();
		}
		logger.info("Data inserted successfully in recruitments systems");
		return true;
	}
	
	
	//method for updating qualifications details
	@Override
	public boolean updateCandidateQualifications(CandidateBeanQualification cqualifications) throws RecruitmentException {
		
		
		Scanner sc = new Scanner(System.in);
		System.out.println("enter qualification ID based on which you want to update");
	String	id = sc.next();
	String sql = "UPDATE Candidate_Qualifications SET qualification_name =?, specialization_area=?, college_name=?, university_name=?, year_of_passing=?, percentage=? where qualification_id=?"; 
		conn = DBUtil.getConnection();
		PreparedStatement pst;
		System.out.println("Enter the Details");
		System.out.println("Enter Qualification name");
		String nm = sc.next();
		System.out.println("enter Specialization area");
		String sa = sc.next();
		System.out.println("enter College name");
		String cn=sc.next();
		System.out.println("enter University name");
		String un=sc.next();
		System.out.println("enter Year of passing");
		String yop=sc.next();
		System.out.println("Enter your Percentage");
		String percentage=sc.next();
		
		
		try {
			pst = conn.prepareStatement(sql);
			
			pst.setString(1, nm);
			pst.setString(2, sa);
			pst.setString(3, cn);
			pst.setString(4, un);
			pst.setString(5, yop);
			pst.setString(6, percentage);
			pst.setString(7, id);
			pst.executeUpdate();
		} catch (SQLException e) {
			logger.error("Problem in inserting the details");
			throw new RecruitmentException("problem in updating the details"+e.getMessage());
			
		}
		logger.info("Data inserted successfully in recruitments systems");
		return true;
	}
	
	
	//method for updating work History details
	@Override
	public boolean updatCandidateWorkHistory(CandidateBeanWorkHistory chistory)
			throws RecruitmentException {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("enter work ID");
		String	id = sc.next();
		String sql = "UPDATE candidate_work_history SET candidate_id =?, which_employer=?, contact_person =?, position_held=?, company_name=?, employee_from=?, employee_to=?, reason_for_leaving=?, responsibilities=?, hr_rep_name=?, hr_rep_contact_number=? where work_id=?"; 
		conn = DBUtil.getConnection();
		PreparedStatement pst;
		
		System.out.println("Enter the Details");
		System.out.println("Enter New candidate id");
		String nm = sc.next();
		System.out.println("enter which employer");
		String add = sc.next();
		System.out.println("enter contact person");
		String dob=sc.next();
		System.out.println("enter position held");
 		String email=sc.next();
		System.out.println("enter company name");
		String cno=sc.next();
		System.out.println("enter employee from");
		String mstatus=sc.next();
		System.out.println("Enter employement to");
		String gender=sc.next();
		System.out.println("enter reason for leaving");
		String pno=sc.next();
		System.out.println("Enter responsibilities");
		String nm1 = sc.next();
		System.out.println("enter hr rep name");
		String add1 = sc.next();
		System.out.println("enter hr rep contact number");
		String dob1=sc.next();
		
		
		try {
			pst = conn.prepareStatement(sql);
			
			pst.setString(1, nm);
			pst.setString(2, add);
			pst.setString(3, dob);
			pst.setString(4, email);
			pst.setString(5, cno);
			pst.setString(6, mstatus);
			pst.setString(7, gender);
			pst.setString(8, pno);
			pst.setString(9, nm1);
			pst.setString(10, add1);
			pst.setString(11, dob1);
			pst.setString(12, id);
			pst.executeUpdate();
		} catch (SQLException e) {
			logger.error("Problem in inserting the details");
			throw new RecruitmentException("problem in updating the details"+e.getMessage());
		}
		logger.info("Data inserted successfully in recruitments systems");
		return true;	
	}
	

	//method for login
	@Override
	public int login(String username, String password, String role)
			throws RecruitmentException {
	
		try {
			conn=DBUtil.getConnection();
			String sql="select count(*) as COUNT from Recruitmentlogin where login_id=? and password=? and role=?";
			PreparedStatement pst;
			pst = conn.prepareStatement(sql);
			
		ResultSet rst;
			pst=conn.prepareStatement(sql);
			pst.setString(1,username);
			pst.setString(2,password);
			pst.setString(3,role);
			rst=pst.executeQuery();
			rst.next();
			int count=Integer.parseInt(rst.getString("COUNT"));
			if(count==1)
				
				return 1;
		} 
		catch (Exception e) 
		{
		
			e.printStackTrace();
			logger.error("Problem in inserting the details");
			throw new RecruitmentException(e.getMessage());
		}
		logger.info("Data inserted successfully in recruitments systems");
		return 2;
		}
	
	
	
	//Method for adding company Details
	@Override
	public String addCompanyDetails(CompanyMaster cmaster) throws RecruitmentException {
		
		cmaster.setCompany_id(generateRegistrationId());
		String sql ="INSERT INTO company_master VALUES(?,?,?,?,?,?)";
		conn = DBUtil.getConnection();
		try {
		PreparedStatement pst=conn.prepareStatement(sql);
		pst.setString(1, cmaster.getCompany_id());
		pst.setString(2, cmaster.getCompany_name());
		pst.setString(3, cmaster.getCompany_address());
		pst.setString(4, cmaster.getContact_person());
		pst.setString(5, cmaster.getEmail_id());
		pst.setString(6, cmaster.getContact_number());
		pst.executeUpdate();
		//logger.info("Registration completed successfully for"+cmaster);
		
	}catch (SQLException e) {
		logger.error("Problem in inserting the details");
		throw new RecruitmentException("problem in inserting"
				+"registration details"+e.getMessage());
	}
		logger.info("Data inserted successfully in recruitments systems");
		return cmaster.getCompany_id();
	}
	
	
//method for updating company details
	@Override
	public boolean updateCompanyDetails() throws RecruitmentException {
		

		Scanner sc = new Scanner(System.in);
		System.out.println("enter company ID");
		String	id = sc.next();
	
		String sql = "UPDATE company_master SET company_name =?, company_address=?, contact_person=?, email_id=?, contact_number=? where company_id=?"; 
		conn = DBUtil.getConnection();
		PreparedStatement pst;
		System.out.println("Enter New Name of Company");
		String nm = sc.next();
		System.out.println("enter company Address");
		String add = sc.next();
		System.out.println("enter contact person");
		String dob=sc.next();
		System.out.println("enter Email ID");
		String email=sc.next();
		System.out.println("enter contact no");
		String cno=sc.next();
		
		
		try {
			pst = conn.prepareStatement(sql);
			
			pst.setString(1, nm);
			pst.setString(2, add);
			pst.setString(3, dob);
			pst.setString(4, email);
			pst.setString(5, cno);
			pst.setString(6, id);
			pst.executeUpdate();
		} catch (SQLException e) {
			logger.error("Problem in inserting the details");
			throw new RecruitmentException("problem in updating the details"+e.getMessage());
			//e.printStackTrace();
		}
		logger.info("Data inserted successfully in recruitments systems");
		return true;
	}
	
	//Method for company to search for candidate based on qualification
	@Override
	public List<CandidateBeanQualification> searchjobs(String jreq) throws RecruitmentException {
		String sql = "SELECT * FROM candidate_qualifications where QUALIFICATION_NAME=?" ;
		ArrayList<CandidateBeanQualification> jlist = new ArrayList<CandidateBeanQualification>();

				try {
					conn=DBUtil.getConnection();
					PreparedStatement pst;
						pst = conn.prepareStatement(sql);
						pst.setString(1, jreq);
						
						ResultSet rst;
						
						rst = pst.executeQuery();
						while(rst.next()) {
							CandidateBeanQualification c1 = new CandidateBeanQualification();
							c1.setQualification_id(rst.getString("QUALIFICATION_ID"));
							c1.setQualification_name(rst.getString("QUALIFICATION_NAME"));
							c1.setSpecialization_area(rst.getString("specialization_area"));
							c1.setCollege_name(rst.getString("college_name"));
							c1.setUniversity_name(rst.getString("university_name"));
							c1.setYear_of_passing(rst.getString("year_of_passing"));
							c1.setPercentage(rst.getString("percentage"));
							c1.setCandidate_id(rst.getString("candidate_id"));
							jlist.add(c1);
							
						}
				} catch (SQLException e) {
					logger.error("Problem in inserting the details");
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				logger.info("Data inserted successfully in recruitments systems");
			return jlist;
			
	}
	
	
//method for company to search candidate using position held
	@Override
	public List<CandidateBeanWorkHistory> searchjobs2(String jreq) throws RecruitmentException {
		String sql = "SELECT * FROM candidate_work_history where position_held=?" ;
		ArrayList<CandidateBeanWorkHistory> jlist2 = new ArrayList<CandidateBeanWorkHistory>();

				try {
					conn=DBUtil.getConnection();
					PreparedStatement pst;
						pst = conn.prepareStatement(sql);
						pst.setString(1, jreq);
						
						ResultSet rst;
						
						rst = pst.executeQuery();
						while(rst.next()) {
							CandidateBeanWorkHistory cw = new CandidateBeanWorkHistory();
							cw.setWork_id(rst.getString("work_id"));
							cw.setCandidate_id(rst.getString("candidate_id"));
							cw.setWhich_employer(rst.getString("which_employer"));
							cw.setContact_person(rst.getString("contact_person"));
							cw.setPosition_held(rst.getString("position_held"));
							cw.setCompany_name(rst.getString("company_name"));
							cw.setEmployement_from(rst.getString("employee_from"));
							cw.setEmployement_to(rst.getString("employee_to"));
							cw.setReason_for_leaving(rst.getString("reason_for_leaving"));
							cw.setResponsibilities(rst.getString("responsibilities"));
							cw.setHr_rep_name(rst.getString("hr_rep_name"));
							cw.setHr_rep_contact_num(rst.getString("hr_rep_contact_number"));
							jlist2.add(cw);
						
						}
				} catch (SQLException e) {
					logger.error("Problem in inserting the details");
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				logger.info("Data inserted successfully in recruitments systems");
			return jlist2;
			}

//method for candidate to search for a particular job based on different criteria.
	@Override
	public List<JobRequirements> searchjobs3(JobRequirements jreq) throws RecruitmentException{
		String sql = "SELECT * FROM job_requirements where qualification_required=? and position_required=? and experience_required=? and job_location=?" ;
		ArrayList<JobRequirements> jlist = new ArrayList<JobRequirements>();

				try {
					conn=DBUtil.getConnection();
					PreparedStatement pst;
						pst = conn.prepareStatement(sql);
						pst.setString(1, jreq.getQualification_required());
						pst.setString(2, jreq.getPosition_required());
						pst.setLong(3, jreq.getExperience_required());
						pst.setString(4, jreq.getJob_location());
						
						ResultSet rst;
						
						rst = pst.executeQuery();
						while(rst.next()) {
							JobRequirements c = new JobRequirements();
							c.setJob_id(rst.getString("job_id"));
							c.setCompany_id(rst.getString("company_id"));
							c.setPosition_required(rst.getString("position_required"));
							c.setNumbers_required(rst.getLong("number_required"));
							c.setExperience_required(rst.getLong("experience_required"));
							c.setQualification_required(rst.getString("qualification_required"));
							c.setJob_location(rst.getString("job_location"));
							c.setJob_description(rst.getString("job_description"));
							jlist.add(c);
						}
						
					
				} catch (SQLException e) {
					logger.error("Problem in inserting the details");
					// TODO Auto-generated catch block
					e.printStackTrace();
				}	
				logger.info("Data inserted successfully in recruitments systems");
			return jlist;
			
	}


	//method for company to insert job requirments
	@Override
	public int insertJobReq(JobRequirements jreq) throws RecruitmentException {
		
		String insertQry="insert into job_requirements values (?,?,?,?,?,?,?,?)";
		try {
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(insertQry);
			pst.setString(1, jreq.getJob_id());
			pst.setString(2, jreq.getCompany_id());
			pst.setString(3, jreq.getPosition_required());
			pst.setLong(4, jreq.getNumbers_required());
			pst.setLong(5, jreq.getExperience_required() );
			pst.setString(6, jreq.getQualification_required());
			pst.setString(7, jreq.getJob_location());
			pst.setString(8, jreq.getJob_description());
			data = pst.executeUpdate();
		} 
		catch (Exception e) 
		{
			//daoLogger.error(e.getMessage());
			e.printStackTrace();
			logger.error("Problem in inserting the details");
			throw new RecruitmentException(e.getMessage());
		}
		logger.info("Data inserted successfully in recruitments systems");
		//daoLogger.info(data+ "Data inserted");
		return data;

		
	}

//method for candidate to apply for a job
	@Override
	public int apply(String candidate_id, String job_id,String company_id) throws RecruitmentException {
		String sql = "INSERT INTO apply values(?,?,?,?)";
		conn = DBUtil.getConnection();
		PreparedStatement pst;
		
		try {
			pst = conn.prepareStatement(sql);
			String status = "Applied";
			pst.setString(1,candidate_id);
			pst.setString(2, job_id);
			pst.setString(3, company_id);
			pst.setString(4, status);
			
			pst.executeUpdate();
			} catch (SQLException e) {
				logger.error("Problem in inserting the details");
			throw new  RecruitmentException("problem in insering the details"+e.getMessage());
			
		}
		logger.info("Data inserted successfully in recruitments systems");
		return 1;
		
			
			
	}

//List for a admin to generate report
	@Override
	public List<Admin> gatAllCandidate() throws RecruitmentException {
		String sql = "SELECT candidate_id,company_id,job_id,status from apply";
		ArrayList<Admin> clist = new ArrayList();
		conn = DBUtil.getConnection();
		
		Statement st;
		try {
			st = conn.createStatement();
			ResultSet rst = st.executeQuery(sql);
			
			while(rst.next()) {
				Admin c = new Admin();
				c.setCandidate_id(rst.getString("candidate_id"));
				c.setCompany_id(rst.getString("company_id"));
				c.setJob_id(rst.getString("job_id"));
				c.setStatus(rst.getString("status"));
				clist.add(c);
			}
				
		} catch (SQLException e) {
			logger.error("Problem in inserting the details");
			
			throw new RecruitmentException("problem in fetching the deatails"+e.getMessage());
		}
		logger.info("Data inserted successfully in recruitments systems");
		
		return clist;	
}
		
		
	}
	
	
