package com.cg.rms.testing;

import static org.junit.Assert.*;

import org.junit.Test;



import com.cg.rms.dao.RecruitmentDao;
import com.cg.rms.dto.CandidateBeanPersonal;
import com.cg.rms.exception.RecruitmentException;
import com.cg.rms.service.CourseServiceImpl;

public class RecruitmentTesting {
	
	CourseServiceImpl cimpl = new CourseServiceImpl(); 
	RecruitmentDao rdao;
	
	@Test
	public void Testinsertcource(){
		
		CandidateBeanPersonal cpp = new CandidateBeanPersonal();
		cpp.setCandidate_name("Dinesh");
		
		try {
			String reg = rdao.insertCourse(cpp);
			assertNotNull(reg);
		} catch (RecruitmentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
		
	
	
	
	
	

	@Test
	public void loginAdminTest() throws RecruitmentException{
		CourseServiceImpl cimpl = new CourseServiceImpl(); 
		assertEquals(1, cimpl.login("Dinesh", "Dinesh", "admin"));
	}
	

	@Test
	public void loginCandidateTest() throws RecruitmentException{
		CourseServiceImpl cimpl = new CourseServiceImpl(); 
		assertEquals(1, cimpl.login("Shreya", "Shreya", "candidate"));
	}
	

	@Test
	public void loginCompanyTest() throws RecruitmentException{
		CourseServiceImpl cimpl = new CourseServiceImpl(); 
		assertEquals(1, cimpl.login("Mayur", "Mayur", "company"));
	}
	

}
